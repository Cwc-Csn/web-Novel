#-*-codeing=utf-8 -*-
#@Time :2021/1/2 16:04
#@Author :Csn
#@File:GetText
#@Software:PyCharm

#爬取笔趣网小说
import gzip
from io import BytesIO

import requests
import os
from bs4 import BeautifulSoup
import urllib.request
import urllib.error
#
# def get_book():
#     url='http://www.biquw.com/book/16583/'
#     # head = { "User-Agent": "Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/78.0.3904.108 Safari/537.36"}
#     head={"User-Agent": "Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/78.0.3904.108 Safari/537.36"}
#     request = urllib.request.Request(url, headers=head)
#     html=''
#     # data=requests.get(url).text.encode('utf-8')
#     try:
#         response=urllib.request.urlopen(request)
#         conten=response.read()
#         buff = BytesIO(conten)
#         f = gzip.GzipFile(fileobj=buff)
#         html=f.read().decode("utf-8")
#
#     except urllib.error.URLError as e:
#         if hasattr(e,"code"):
#             print(e.code)
#         if hasattr(e, "reason"):
#             print(e.reason)
#     soup=BeautifulSoup(html,'html.parser')
#     data=soup.find('ul')
#     for book in data.find_all('a'):
#         # print(book.text,book['href'])
#         book_url=url+book['href']
#         # print(book_url)
#
#         content = urllib.request.Request(book_url, headers=head)
#         response = urllib.request.urlopen(content)
#         response1=response.read()
#         buff = BytesIO(response1)
#         f = gzip.GzipFile(fileobj=buff)
#         content1=f.read().decode('utf-8')
#         soup1=BeautifulSoup(content1,'html.parser')
#         book_content=soup1.find('div',{'id':'htmlContent'}).text
#
#         if not os.path.exists('./小说/'):
#             os.makedirs('./小说/')
#
#         with open('./小说/'+book.text+'.txt','w',encoding='utf-8') as f:
#             f.write(book_content)
#             print(book['href']+'完成')
#         # print(content1)
#
#     # print(data)

'''
优化版， 写一个函数  gzip压缩过的数据，进行解码
'''
def decode_translate(response):
    conten = response.read()
    buff = BytesIO(conten)
    f = gzip.GzipFile(fileobj=buff)
    html = f.read().decode("utf-8")
    return html


def get_book():
    url='http://www.biquw.com/book/16583/'
    # head = { "User-Agent": "Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/78.0.3904.108 Safari/537.36"}
    head={"User-Agent": "Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/78.0.3904.108 Safari/537.36"}
    request = urllib.request.Request(url, headers=head)

    # data=requests.get(url).text.encode('utf-8')
    try:
        response=urllib.request.urlopen(request)
        # conten=response.read()
        # buff = BytesIO(conten)
        # f = gzip.GzipFile(fileobj=buff)
        # html=f.read().decode("utf-8")
        html= decode_translate(response)
        # print(html)

    except urllib.error.URLError as e:
        if hasattr(e,"code"):
            print(e.code)
        if hasattr(e, "reason"):
            print(e.reason)
    soup=BeautifulSoup(html,'html.parser')
    data=soup.find('ul')
    for book in data.find_all('a'):
        # print(book.text,book['href'])
        book_url=url+book['href']
        # print(book_url)

        content = urllib.request.Request(book_url, headers=head)
        response = urllib.request.urlopen(content)
        # response1=response.read()
        #         # buff = BytesIO(response1)
        #         # f = gzip.GzipFile(fileobj=buff)
        #         # content1=f.read().decode('utf-8')
        content1=decode_translate(response)
        soup1=BeautifulSoup(content1,'html.parser')
        book_content=soup1.find('div',{'id':'htmlContent'}).text

        if not os.path.exists('./小说/'):
            os.makedirs('./小说/')

        with open('./小说/'+book.text+'.txt','w',encoding='utf-8') as f:
            f.write(book_content)
            print(book['href']+'完成')
        # print(content1)

    # print(data)
if __name__=='__main__':
    get_book()